package com.techbeast.kanban.bck.service.constants;

public class TaskConstants {
	public static final String STATUS_ONE= "Backlog";
	public static final String STATUS_TWO= "WIP";
	public static final String STATUS_THREE= "Completed";
}
