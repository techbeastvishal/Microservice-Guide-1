package com.techbeast.kanban.bck.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KanbanBackendServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
