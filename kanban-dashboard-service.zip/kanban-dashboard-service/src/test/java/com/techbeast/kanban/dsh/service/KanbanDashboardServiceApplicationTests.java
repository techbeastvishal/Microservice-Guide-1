package com.techbeast.kanban.dsh.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KanbanDashboardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
