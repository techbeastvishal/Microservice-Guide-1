package com.techbeast.kanban.emp.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KanbanEmployeeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
