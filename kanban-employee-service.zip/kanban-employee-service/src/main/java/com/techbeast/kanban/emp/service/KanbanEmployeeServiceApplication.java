package com.techbeast.kanban.emp.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KanbanEmployeeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(KanbanEmployeeServiceApplication.class, args);
	}

}
