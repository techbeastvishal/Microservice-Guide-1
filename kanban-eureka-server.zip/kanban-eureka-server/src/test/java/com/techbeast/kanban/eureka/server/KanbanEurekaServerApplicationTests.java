package com.techbeast.kanban.eureka.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KanbanEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
